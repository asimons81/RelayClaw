import type {
  OpenClawPluginApi,
  PluginHookAgentContext,
  PluginHookSessionContext,
  PluginHookSessionStartEvent,
  PluginHookSessionEndEvent,
  PluginHookBeforePromptBuildEvent,
  PluginHookBeforePromptBuildResult,
  PluginHookLlmOutputEvent,
  PluginHookAgentEndEvent,
  PluginHookBeforeToolCallEvent,
  PluginHookBeforeToolCallResult,
  PluginHookToolContext,
  PluginHookGatewayContext,
  PluginHookGatewayStartEvent,
  PluginHookGatewayStopEvent,
} from "./src/types/openclaw.js";
import { resolveRelayClawConfig, type RelayClawConfig } from "./src/config.js";
import { getSupabaseClient } from "./src/supabase-client.js";

// ---------------------------------------------------------------------------
// RelayClaw plugin entry
//
// Follows the third-party plugin pattern from:
//   /home/tony/.openclaw/extensions/byterover/index.ts
//
// Uses structural typing for OpenClawPluginApi (defined locally in
// src/types/openclaw.ts) so the plugin typechecks without openclaw being
// installed as a full package — openclaw is a peer dependency resolved at
// runtime by the gateway.
// ---------------------------------------------------------------------------

const relayClawPlugin = {
  id: "relayclaw",
  name: "RelayClaw",
  description:
    "Agent handoff and context bridge system — structured state transfer, dead-drop recovery, approval gates, cost ledger, and chain visibility across the OpenClaw agent crew.",

  register(api: OpenClawPluginApi) {
    // -------------------------------------------------------------------------
    // Config resolution — throws early if supabaseUrl/supabaseServiceKey absent
    // -------------------------------------------------------------------------
    let config: RelayClawConfig;
    try {
      config = resolveRelayClawConfig(api.pluginConfig);
    } catch (err) {
      api.logger.error(err instanceof Error ? err.message : String(err));
      api.logger.warn("[relayclaw] Plugin loaded with errors — some features will be unavailable");
      return;
    }

    // Lazy Supabase client — initialised on first tool/hook use, not at registration time
    const getDb = () => getSupabaseClient(config);

    // -------------------------------------------------------------------------
    // Tool: relay_handoff
    // Agent-facing multi-action tool for create / inject / list / inspect / complete
    // -------------------------------------------------------------------------
    api.registerTool({
      name: "relay_handoff",
      label: "Relay Handoff",
      description:
        "Create, inject, list, or inspect agent handoff documents for structured state transfer between agents. " +
        "Actions: create (serialize current state for another agent), inject (load a queued handoff into context), " +
        "list (browse available handoffs), inspect (full detail of a handoff), complete (mark an injected handoff done).",
      parameters: {
        type: "object",
        required: ["action"],
        properties: {
          action: {
            type: "string",
            enum: ["create", "inject", "list", "inspect", "complete"],
            description: "The operation to perform.",
          },
          // create params
          target_agent: { type: "string", description: "[create] Target agent ID (e.g. 'sabbath')" },
          goal: { type: "string", description: "[create] What the target agent should accomplish" },
          status_summary: { type: "string", description: "[create] What has been accomplished so far" },
          decisions: { type: "array", items: { type: "object" }, description: "[create] Key decisions made" },
          artifacts: { type: "array", items: { type: "object" }, description: "[create] Files/outputs produced" },
          blockers: { type: "array", items: { type: "object" }, description: "[create] Current blockers" },
          next_steps: { type: "array", items: { type: "object" }, description: "[create] Recommended next steps" },
          confidence: { type: "number", minimum: 0, maximum: 1, description: "[create] Confidence level 0-1" },
          notes: { type: "string", description: "[create] Additional notes" },
          chain_id: { type: "string", description: "[create] Existing chain ID to append to" },
          merge_strategy: {
            type: "string",
            enum: ["merge", "replace", "flag_conflict"],
            description: "[create] How to handle parallel handoffs targeting the same agent",
          },
          // inject params
          handoff_id: { type: "string", description: "[inject/inspect/complete] Handoff UUID" },
          from_queue: { type: "boolean", description: "[inject] Pop next item from my queue" },
          // list params
          filter: { type: "string", enum: ["pending", "queued", "all"], description: "[list] Status filter" },
          agent: { type: "string", description: "[list] Filter by agent ID" },
          // complete params
          result_summary: { type: "string", description: "[complete] Summary of what was accomplished" },
        },
      },
      async execute(_toolCallId, _params) {
        // TODO: implement in handoff/create.ts, handoff/inject.ts, etc.
        void getDb();
        return {
          content: [{ type: "text" as const, text: JSON.stringify({ error: "not implemented" }) }],
        };
      },
    });

    // -------------------------------------------------------------------------
    // CLI: openclaw handoff <subcommand>
    // Human-facing commands for list / inspect / approve / reject / redirect / cost
    // -------------------------------------------------------------------------
    api.registerCli(
      ({ program }: { program: { command: (name: string) => unknown } }) => {
        // TODO: implement in src/cli.ts
        void program;
        void getDb();
      },
      {
        descriptors: [
          {
            name: "handoff",
            description: "Manage RelayClaw agent handoffs",
            hasSubcommands: true,
          },
        ],
      },
    );

    // -------------------------------------------------------------------------
    // HTTP routes
    // -------------------------------------------------------------------------

    // POST /plugins/relayclaw/heartbeat — rolling task snapshots from agents
    api.registerHttpRoute({
      path: "/plugins/relayclaw/heartbeat",
      auth: "plugin" as const,
      handler: async (_req: unknown, res: { json: (body: unknown) => void }) => {
        // TODO: implement in src/http.ts
        void getDb();
        res.json({ ok: true, stub: true });
      },
    });

    // POST /plugins/relayclaw/approve — approval webhook (Telegram inline / external)
    api.registerHttpRoute({
      path: "/plugins/relayclaw/approve",
      auth: "plugin" as const,
      handler: async (_req: unknown, res: { json: (body: unknown) => void }) => {
        // TODO: implement in src/http.ts
        void getDb();
        res.json({ ok: true, stub: true });
      },
    });

    // GET /plugins/relayclaw/status — health endpoint
    api.registerHttpRoute({
      path: "/plugins/relayclaw/status",
      auth: "plugin" as const,
      handler: async (_req: unknown, res: { json: (body: unknown) => void }) => {
        // TODO: implement in src/http.ts
        res.json({ plugin: "relayclaw", version: "0.1.0", status: "ok" });
      },
    });

    // -------------------------------------------------------------------------
    // Gateway methods
    // -------------------------------------------------------------------------
    const gatewayStub =
      (method: string) =>
      async ({ respond }: { respond: (ok: boolean, payload?: unknown) => void }) => {
        // TODO: implement in src/gateway.ts
        respond(false, { error: `${method} not yet implemented` });
      };

    api.registerGatewayMethod("relayclaw.handoff.create", gatewayStub("relayclaw.handoff.create"));
    api.registerGatewayMethod("relayclaw.handoff.approve", gatewayStub("relayclaw.handoff.approve"));
    api.registerGatewayMethod("relayclaw.handoff.reject", gatewayStub("relayclaw.handoff.reject"));
    api.registerGatewayMethod("relayclaw.handoff.list", gatewayStub("relayclaw.handoff.list"));
    api.registerGatewayMethod("relayclaw.handoff.inspect", gatewayStub("relayclaw.handoff.inspect"));
    api.registerGatewayMethod("relayclaw.queue.peek", gatewayStub("relayclaw.queue.peek"));
    api.registerGatewayMethod("relayclaw.heartbeat.status", gatewayStub("relayclaw.heartbeat.status"));
    api.registerGatewayMethod("relayclaw.cost.summary", gatewayStub("relayclaw.cost.summary"));

    // -------------------------------------------------------------------------
    // Lifecycle hooks
    // -------------------------------------------------------------------------

    // session_start — start heartbeat timer, record session wall-clock start
    api.on(
      "session_start",
      async (event: PluginHookSessionStartEvent, ctx: PluginHookSessionContext) => {
        // TODO: implement in src/heartbeat/sender.ts
        void event; void ctx; void config;
      },
    );

    // session_end — stop heartbeat timer, mark heartbeat ended cleanly
    api.on(
      "session_end",
      async (event: PluginHookSessionEndEvent, ctx: PluginHookSessionContext) => {
        // TODO: implement in src/heartbeat/sender.ts
        void event; void ctx;
      },
    );

    // before_prompt_build — inject pending handoff as system prompt section
    api.on(
      "before_prompt_build",
      async (
        event: PluginHookBeforePromptBuildEvent,
        ctx: PluginHookAgentContext,
      ): Promise<PluginHookBeforePromptBuildResult | void> => {
        // TODO: implement in src/handoff/inject.ts
        void event; void ctx;
        return undefined;
      },
    );

    // llm_output — accumulate token usage for cost ledger
    api.on(
      "llm_output",
      async (event: PluginHookLlmOutputEvent, ctx: PluginHookAgentContext) => {
        // TODO: implement in src/cost/ledger.ts
        void event; void ctx;
      },
    );

    // agent_end — flush token accumulator to cost_ledger, clean up heartbeat
    api.on(
      "agent_end",
      async (event: PluginHookAgentEndEvent, ctx: PluginHookAgentContext) => {
        // TODO: implement in src/cost/ledger.ts + src/heartbeat/sender.ts
        void event; void ctx; void getDb();
      },
    );

    // before_tool_call — inject trusted agent_id/session_key into relay_handoff params
    api.on(
      "before_tool_call",
      async (
        event: PluginHookBeforeToolCallEvent,
        ctx: PluginHookToolContext,
      ): Promise<PluginHookBeforeToolCallResult | void> => {
        // TODO: implement in src/hooks.ts
        // Only intercepts calls to "relay_handoff" — injects trusted identifiers
        // to prevent agents from forging their own identity in handoff creates.
        void event; void ctx;
        return undefined;
      },
    );

    // gateway_start — start dead-drop monitor service
    api.on(
      "gateway_start",
      async (event: PluginHookGatewayStartEvent, ctx: PluginHookGatewayContext) => {
        // TODO: implement in src/heartbeat/monitor.ts
        void event; void ctx; void config;
      },
    );

    // gateway_stop — stop dead-drop monitor and queue conflict scanner
    api.on(
      "gateway_stop",
      async (event: PluginHookGatewayStopEvent, ctx: PluginHookGatewayContext) => {
        // TODO: implement in src/service.ts
        void event; void ctx;
      },
    );

    // -------------------------------------------------------------------------
    // Background services
    // -------------------------------------------------------------------------

    // Dead-drop monitor — promotes stale heartbeats to interrupted handoffs
    api.registerService({
      id: "relayclaw-dead-drop-monitor",
      start: async () => {
        // TODO: implement in src/heartbeat/monitor.ts
        // Polls heartbeats every 60s. Calls promote_heartbeat_to_handoff() for
        // any agent whose last heartbeat exceeds deadDropThresholdMs.
        api.logger.info("[relayclaw] dead-drop monitor started (stub)");
      },
      stop: async () => {
        // TODO: clear polling interval
        api.logger.info("[relayclaw] dead-drop monitor stopped");
      },
    });

    // Queue conflict scanner — detects agents with multiple pending handoffs
    api.registerService({
      id: "relayclaw-queue-conflict-scanner",
      start: async () => {
        // TODO: implement in src/queue/conflict.ts
        // Polls agent_queues every 120s. Applies merge_strategy or notifies human.
        api.logger.info("[relayclaw] queue conflict scanner started (stub)");
      },
      stop: async () => {
        // TODO: clear polling interval
        api.logger.info("[relayclaw] queue conflict scanner stopped");
      },
    });

    api.logger.info("[relayclaw] Plugin loaded");
  },
};

export default relayClawPlugin;
